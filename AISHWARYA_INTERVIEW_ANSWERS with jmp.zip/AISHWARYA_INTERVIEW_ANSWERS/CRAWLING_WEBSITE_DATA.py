#!/usr/bin/env python
# coding: utf-8

# In[105]:


**READ ME**

WE USE THE BEAUTIFUL SOUP AND OTHER RELATED LIBRARIES TO PERFROM WER CRAWLING AND OUT THE TABLE DATA


# In[ ]:


from urllib.request import urlopen
from bs4 import BeautifulSoup as soup
import re
import json


# In[107]:


from urllib.request import urlopen
from bs4 import BeautifulSoup as soup
import re
import json
url_list = ["https://www.sgcarmart.com/used_cars/info.php?ID=1052507&DL=3919",
            "https://www.sgcarmart.com/used_cars/info.php?ID=1052507&DL=3919"]   
for i in url_list:
#first = urlopen("https://www.sgcarmart.com/used_cars/info.php?ID=1052507&DL=3919")
first = urlopen(i)
bsobj = soup(first.read())
newlist = []
newlist2 = []
srt = ''
for data in bsobj.find('table',{'id':'carInfo'}).findAll('tr'):
       attr.append(data.text.strip().replace('\t', ""))
       newlist = [s.strip() for s in attr]
print(newlist)
# split_string = srt.split("Features", 1)


# substring = split_string[0]
# print(substring)

               


# In[ ]:





# In[ ]:




