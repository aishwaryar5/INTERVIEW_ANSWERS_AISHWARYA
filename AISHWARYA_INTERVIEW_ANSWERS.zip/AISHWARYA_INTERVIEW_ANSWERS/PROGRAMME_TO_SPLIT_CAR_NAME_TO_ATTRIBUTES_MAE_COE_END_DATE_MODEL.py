#!/usr/bin/env python
# coding: utf-8

# In[ ]:



**READ ME: CODE TO EXTRACT THE CAR MAKE, MODEL AND COE END DATE FROM THE CAR NAME COLUMN USING PYTHON REGEX**


# In[1]:


# importing module
from pandas import *
import re
from datetime import date
# reading CSV file
data = read_csv("masterdata.csv")

# converting column data to list
Car_Name = data['Car Name'].tolist()
Car_Model = []
COE_END_DATE = []
timeline2 = []
timeline3 = []
#print(Car_Name)
for i in Car_Name:
    x = i.split()
    #print(x)
    for j in x:
        timeline = re.compile(r'^[0-9]*[-][yr]')
        coe = re.compile(r'(?<![/\d])(?:0\d|[1][012])/(?:19|20)?\d{2}(?![/\d])')
        r = re.compile(r'^[0-9]*[.,]{0,1}[0-9][a-zA-Z]*$')
        if r.match(j):
           Car_Model.append(j)
        if coe.match(j):
            p = (j[:-1])
            COE_END_DATE.append(p)
        if timeline.match(j):
           timeline2.append(j)
           for z in timeline2: 
                y = z.split('-')
                k =y[0]
                todays_date = date.today()
                COE_END_DATE_2 = int(todays_date.year) + int(k)
                COE_END_DATE.append(COE_END_DATE_2)
   
        #print(j)
# printing list data
#print('Car Names are:', Car_Name)
#print(timeline3)
#print(COE_END_DATE_2)
#print("COE END DATE IS:", COE_END_DATE)
Car_Make = [re.match(r'[^\d]+', x).group(0) for x in Car_Name]
print("CAR MAKE IS:", Car_Make)
#print("CAR MODEL IS:",Car_Model)


# In[ ]:


import csv

# open the file in the write mode
f = open('C:\Users\Aishwarya.R\OneDrive\Desktop\MICRON MURUGA\car_model.csv', 'w')

# create the csv writer
writer = csv.writer(f)

# write a row to the csv file
writer.writerow(row)

# close the file
f.close()


# In[ ]:




