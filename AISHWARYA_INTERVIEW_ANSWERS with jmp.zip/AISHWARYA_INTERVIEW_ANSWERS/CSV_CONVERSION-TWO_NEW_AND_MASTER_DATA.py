#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
df1 = pd.read_csv('NewData.csv')
df2 = pd.read_csv('MasterDB.csv')


# In[ ]:


Storing the data in an array will allow the equation below to show the differences.


# In[3]:


array1 = np.array(df1)  
array2 = np.array(df2)


# In[4]:


print(array1)


# In[ ]:


'Car Name','Price','Depreciation','Reg Date','Mileage','Road Tax','Dereg Value','Engine Cap','Curb Weight',
'Manufactured','Transmission','OMV','ARF','Power','No. of Owners','COE','Status'


# In[8]:


df_CSV_1 = pd.DataFrame(array1, columns=['ID','Car Name','Price','Depreciation','Reg Date','Mileage','Road Tax','Dereg Value','Engine Cap','Curb Weight','Manufactured','Transmission','OMV','ARF','Power','No. of Owners','COE','Status'])
df_CSV_2 = pd.DataFrame(array2, columns=['ID','Car Name','Price','Depreciation','Reg Date','Mileage','Road Tax','Dereg Value','Engine Cap','Curb Weight','Manufactured','Transmission','OMV','ARF','Power','No. of Owners','COE','Status'])


# In[9]:


df_CSV_1.index += 1 
df_CSV_2.index += 1 


# In[10]:


print(df_CSV_1.eq(df_CSV_2).to_string(index=True))


# In[ ]:


from csv import writer
filename = MasterDB.csv
def append_list_as_row(file_name, list_of_elem):
    # Open file in append mode
    with open(file_name, 'a+', newline='') as write_obj:
        # Create a writer object from csv module
        csv_writer = writer(write_obj)
        # Add contents of list as last row in the csv file
        csv_writer.writerow(list_of_elem)


# In[ ]:


**Appends data that are there in new data but not in master data**

with open('newDatal.csv', 'r') as f1:
    original = f1.read()

with open('MasterDB.csv, 'a') as f2:
    f2.write('\n')
    f2.write(original)
print((df_CSV_1.eq(df_CSV_2).to_string(index=False))


# In[ ]:



import pandas as pd


df1= pd.read_csv("NewData.csv")
df2 = pd.read_csv("MasterDB.csv")

ID_value = data['ID'].tolist()
Status_data = data['Status'].tolist()
if Status_data == 'SOLD'

df2 =  df2[df.ID != ID_value]  # row will be deleted

df.to_csv(file, index=False)

