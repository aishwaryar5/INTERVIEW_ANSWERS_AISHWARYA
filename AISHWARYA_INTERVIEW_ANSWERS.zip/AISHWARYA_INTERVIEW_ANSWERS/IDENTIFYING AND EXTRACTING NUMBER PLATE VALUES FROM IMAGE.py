#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import cv2
import pytesseract
import matplotlib.pyplot as plt
get_ipython().system('pip install  tesseract')
get_ipython().system('pip install Pillow')
from PIL import Image
get_ipython().system('pip install opencv-python numpy pandas')
pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'
get_ipython().system('pip install  tesseract')
import pytesseract
image_path = C:\Users\Aishwarya.R\Documents\images_folder
def get_image(image_path):
     for i in image_path:
         image = cv2.imread(i)
    
#img = cv2.imread('imagemicron.jpg')
#convert my image to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#perform adaptive threshold so that I can extract proper contours from the image
#need this to extract the name plate from the image. 
thresh = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,21,6)
contours,h = cv2.findContours(thresh,1,2)

#once I have the contours list, i need to find the contours which form rectangles.
#the contours can be approximated to minimum polygons, polygons of size 4 are probably rectangles
largest_rectangle = [0,0]
for cnt in contours:
    approx = cv2.approxPolyDP(cnt,0.01*cv2.arcLength(cnt,True),True)
    if len(approx)==4: #polygons with 4 points is what I need.
        area = cv2.contourArea(cnt)
        if area > largest_rectangle[0]:
            #find the polygon which has the largest size.
            largest_rectangle = [cv2.contourArea(cnt), cnt, approx]

x,y,w,h = cv2.boundingRect(largest_rectangle[1])
#crop the rectangle to get the number plate.
roi=img[y:y+h,x:x+w]
#cv2.drawContours(img,[largest_rectangle[1]],0,(0,0,255),-1)
plt.imshow(roi, cmap = 'gray')
plt.show()


# In[4]:


get_ipython().system('pip install  tesseract')
get_ipython().system('pip install Pillow')
from PIL import Image
pytesseract.pytesseract.tesseract_cmd = 'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'


# In[18]:


gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
thresh = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,21,6)
text = pytesseract.image_to_string(roi)
print("the number plate value is:" +text)
value_list = text.split()
for i in value_list:
    if len(i) == 8:
        print(i[0]+i[1]+i[2]+"-"+i[3]+i[4]+i[5]+i[6]+"-"+i[7])
    if len(i) == 7:
        print(i[0]+i[1]+"-"+i[2]+i[3]+i[4]+i[5]+"-"+i[6])


# In[ ]:


** READ ME STEPS INVOLVED IN: IDENTIFYING AND EXTRACTING NUMBER PLATE VALUES FROM IMAGE **
    `1.IMPORT NUMPY, CV2, MATPLOTLIB AND OTHER REQUIRED LIBRARIES
     2.INSTALL OPENCV-PYTHON NUMPY PANDAS
     3. TO RESIZE AND ALTER IMAGE USING GREYING ETC TO HELP EXTRACT THE REQUIRED INFORMATION
     4. INSTALL TERASECT
     5. CONVERT THE OBTAINED NUMBER PLAT INFORMATION TO TEXT 
     6. DISPLAY THE OUTPUT AS  STRINGS
     7.SPLIT THE STRING AS [XXX]-[0000]-[X] 


# In[ ]:





# In[ ]:




