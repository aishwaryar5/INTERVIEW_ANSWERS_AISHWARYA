#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import statistics
from pandas import *
import re
data = read_csv("QUESTION3_ANALYTICS_ON_CAR_MAKE.csv")
#print(data)
Car_data = data['COUNT  OF CAR'].tolist()
#print(Car_data)
print( "Mean Value of Car Make", statistics.mean(Car_data))


# In[ ]:


def my_median(sample):
   n = len(sample)
   index = n // 2
    if n % 2:
         return sorted(sample)[index]
    # Sample with an even number of observations
    return sum(sorted(sample)[index - 1:index + 1]) / 2


# In[ ]:


import pandas as pd

df = pd.read_csv('QUESTION3_ANALYTICS_ON_CAR_MAKE.csv')
print(df)


# In[ ]:


print(df.std())


# In[ ]:




